<?php
	define ('WORDS_TO_TRACK', "twitter");
	define ('TWITTER_USERNAME', "");
	define ('TWITTER_PASSWORD', "");
?>